

function encendre(bombeta) {
    bombeta.src="img/llumon.gif";
}
function apagat(bombeta) {
    bombeta.src="img/llumoff.gif"
}
function trencar(bombeta) {
    bombeta.src="img/llumbreak.gif"
}
function teclaon(bombeta) {
    
}
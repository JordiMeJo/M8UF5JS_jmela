function enviarSalutacio() {
    var nom = document.getElementById ('nom')
    var cognom = document.getElementById ('cognom')
    alert ('Hola' + nom + cognom + 'Bon dia senyor')
}

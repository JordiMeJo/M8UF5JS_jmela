
function veureMes () {
    document.getElementById('mestext').style.display = 'block';
}